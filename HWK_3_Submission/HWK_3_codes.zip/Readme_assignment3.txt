Assignment_3_q1_2.py

Contains the code for rejection sampling. 
python3 Assignment_3_q1_2.py

+++++++++++++++++++++++++++++++++++++++++++++++++++++
Assignment_3_q2_1_new.py

Contains the code for finding the best team for team aces and team bruisers and also best team aces to face team bruisers player 1 to 10. 

I have coded with the Pickle file as I had saved the data. We can just comment that line out and uncomment the commented block above that to get the original samples. 

python3 Assignment_3_q2_1_new.py
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Assignment_3_q2_2.py

Contains the code for probability of disease given the symtoms. I have explained the code in the submission of assignment 
python3 Assignment_3_q2_2.py
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Assignment_3_q2_3.py

Contains the code generating the random samples and also metropolis hastings. THe variance and variance square values can be updated to the values. 

python3 Assignment_3_q2_3.py
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Assignment_3_q2_3_c.py

Contains the code for gibbs sampling where random data is generated first. Shuffled and then samples are generated and thier mean is calculated. 
python3 Assignment_3_q2_3_c.py
++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Assignment_3_q3_1_a.py

Contains the code for loopy belief propagation, the enumeration and also the mean error between the 2. 

python3 Assignment_3_q3_a.py
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++=

Assignment_3_q3_1.py

Contains the code for mean field propagation, the enumeration and also the mean error between the 2. 

python3 Assignment_3_q3.py
